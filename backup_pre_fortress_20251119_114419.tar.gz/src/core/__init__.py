"""Core utilities and shared components."""
