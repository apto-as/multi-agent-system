"""FastAPI Presentation Layer

This module provides HTTP endpoints for MCP connection management.
"""
