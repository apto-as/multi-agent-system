"""FastAPI Routers

This module contains all API endpoint routers.
"""
