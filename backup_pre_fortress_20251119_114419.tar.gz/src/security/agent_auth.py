"""Agent authentication and authorization for TMWS v2.0.
Provides secure multi-agent access control.
"""

from datetime import datetime, timedelta
from typing import Any

import jwt

from ..core.config import settings
from ..models.agent import AccessLevel
from ..utils.security import generate_api_key


class AgentAuthService:
    """Service for agent authentication and authorization."""

    def __init__(self):
        if not settings.secret_key:
            raise RuntimeError(
                "TMWS_SECRET_KEY environment variable is required. "
                "Set it to a secure random string (minimum 32 characters).",
            )
        self.secret_key = settings.secret_key
        self.algorithm = "HS256"
        self.access_token_expire_minutes = 60
        self.agent_sessions = {}  # Store agent session data

    def generate_api_key(self) -> str:
        """Generate a secure API key for an agent."""
        return generate_api_key()

    def create_access_token(
        self, agent_id: str, namespace: str = "default", expires_delta: timedelta | None = None,
    ) -> str:
        """Create a JWT access token for an agent."""
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=self.access_token_expire_minutes)

        to_encode = {
            "sub": agent_id,
            "namespace": namespace,
            "exp": expire,
            "iat": datetime.utcnow(),
        }

        encoded_jwt = jwt.encode(to_encode, self.secret_key, algorithm=self.algorithm)
        return encoded_jwt

    def verify_access_token(self, token: str) -> dict[str, Any] | None:
        """Verify and decode a JWT access token."""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.JWTError:
            return None

    async def verify_agent_token(self, token: str) -> dict[str, Any]:
        """Verify agent token and return payload. Async version for FastAPI compatibility."""
        payload = self.verify_access_token(token)
        if payload is None:
            from fastapi import HTTPException, status

            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token",
            )
        # Add session_id if not present
        if "session_id" not in payload:
            payload["session_id"] = f"session_{payload.get('sub', 'unknown')}"
        return payload

    def check_memory_access(
        self,
        agent_id: str,
        agent_namespace: str,
        memory_agent_id: str,
        memory_namespace: str,
        memory_access_level: AccessLevel,
        shared_agents: list[str] = None,
    ) -> bool:
        """Check if an agent can access a specific memory."""

        # Owner always has access
        if agent_id == memory_agent_id:
            return True

        # Check access level
        if memory_access_level == AccessLevel.PUBLIC or memory_access_level == AccessLevel.SYSTEM:
            return True
        elif memory_access_level == AccessLevel.TEAM:
            # Same namespace means same team
            return agent_namespace == memory_namespace
        elif memory_access_level == AccessLevel.SHARED:
            # Check explicit sharing
            return shared_agents and agent_id in shared_agents
        else:  # PRIVATE
            return False

    def generate_agent_token(self, agent_id: str, api_key: str) -> str | None:
        """Generate a token after validating agent credentials."""
        # This would check against database in production
        # For now, simple validation
        if not agent_id or not api_key:
            return None

        # Create token
        return self.create_access_token(agent_id)


class MemoryAccessControl:
    """Fine-grained access control for memories."""

    def __init__(self):
        self.permissions = {
            "read": 1,
            "write": 2,
            "share": 4,
            "delete": 8,
        }

    def has_permission(
        self,
        agent_id: str,
        memory_owner_id: str,
        required_permission: str,
        granted_permissions: int = 1,  # Default read-only
    ) -> bool:
        """Check if agent has required permission on memory."""

        # Owner has all permissions
        if agent_id == memory_owner_id:
            return True

        # Check specific permission
        required_perm_value = self.permissions.get(required_permission, 0)
        return (granted_permissions & required_perm_value) == required_perm_value

    def grant_permissions(self, *permissions: str) -> int:
        """Create permission bitmask from permission names."""
        result = 0
        for perm in permissions:
            result |= self.permissions.get(perm, 0)
        return result


# RateLimiter removed - use the comprehensive implementation from rate_limiter.py instead:
# from .rate_limiter import RateLimiter


def create_agent_authenticator(secret_key: str | None = None) -> AgentAuthService:
    """Factory function to create AgentAuthService instance."""
    authenticator = AgentAuthService()
    if secret_key:
        authenticator.secret_key = secret_key
    return authenticator
