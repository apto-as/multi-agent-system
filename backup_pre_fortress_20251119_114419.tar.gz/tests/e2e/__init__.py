"""E2E (End-to-End) tests package."""
